package com.algorithm.wificellgsignalstrength

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point for Hilt. The @HiltAndroidApp annotation generates the
 * dependency-injection container that lives for the whole app process; every
 * @AndroidEntryPoint activity and @HiltViewModel is wired from here.
 *
 * Registered in AndroidManifest.xml via android:name=".SignalApp".
 */
@HiltAndroidApp
class SignalApp : Application()
