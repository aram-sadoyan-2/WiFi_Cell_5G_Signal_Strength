package com.algorithm.wificellgsignalstrength.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.algorithm.wificellgsignalstrength.data.repository.SignalRepository
import com.algorithm.wificellgsignalstrength.data.speedtest.RealSpeedTester
import com.algorithm.wificellgsignalstrength.ui.model.SignalUiState
import com.algorithm.wificellgsignalstrength.ui.model.SpeedCircleState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Owns the screen state. It combines two streams:
 *  - the live signal readings from [SignalRepository.signalUpdates]
 *  - the speed-test progress it drives itself via [RealSpeedTester]
 *
 * The activity only observes [uiState] and forwards user intents; it holds no
 * system-service or lifecycle-registration logic anymore.
 */
@HiltViewModel
class SignalViewModel @Inject constructor(
    private val repository: SignalRepository,
    private val speedTester: RealSpeedTester
) : ViewModel() {

    private val speedTestState = MutableStateFlow<SpeedCircleState>(SpeedCircleState.Idle)

    val uiState: StateFlow<SignalUiState> =
        combine(repository.signalUpdates(), speedTestState) { base, speed ->
            base.copy(speedTest = speed)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            initialValue = repository.currentSnapshot()
        )

    private var speedTestJob: Job? = null

    /** Ask the repository for an immediate re-read (e.g. right after a permission grant). */
    fun refresh() {
        repository.requestRefresh()
    }

    fun runSpeedTest() {
        speedTestJob?.cancel()
        speedTestJob = viewModelScope.launch {
            try {
                val result = speedTester.run(
                    onDownloadProgress = { mbps, ping ->
                        speedTestState.value = SpeedCircleState.Downloading(
                            downloadMbps = mbps,
                            pingMs = ping
                        )
                    },
                    onUploadProgress = { mbps, ping ->
                        speedTestState.value = SpeedCircleState.Uploading(
                            uploadMbps = mbps,
                            pingMs = ping
                        )
                    }
                )

                speedTestState.value = SpeedCircleState.FinalResult(
                    downloadMbps = result.downloadMbps,
                    uploadMbps = result.uploadMbps,
                    pingMs = result.pingMs
                )

                repository.persistSpeedResult(result.uploadMbps, result.pingMs)
                repository.updateSpeedWidget()
            } catch (_: Exception) {
                speedTestState.value = SpeedCircleState.Idle
            }
        }
    }

    fun resetSpeedTest() {
        speedTestJob?.cancel()
        speedTestJob = null
        speedTestState.value = SpeedCircleState.Idle
    }

    companion object {
        private const val STOP_TIMEOUT_MS = 5000L
    }
}
